import React, { Component } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip} from 'recharts';
import data from '../data/DATA.json'


export default class SimpleLineChart extends Component {
  render(){
    return (
      <div>
        <LineChart width={600} height={400} data={data}>
          <Line type='monotone' dataKey='pv' stroke='#8884d8' strokeWidth={2} />
          <CartesianGrid stroke="#ccc" strokeDasharray="5 5" />

          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
        </LineChart>
      </div>
    )
  }
}

// ReactDOM.render(
//   <SimpleLineChart />,
//   document.getElementById('container')
// );
