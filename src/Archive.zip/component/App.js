import React, { Component } from 'react'
import {Navbar, Nav, NavItem, NavDropdown, MenuItem} from 'react-bootstrap';

import '../stylesheet/main.css'
import '../stylesheet/home.css'
import Background from '../image/syria.jpg';




class App extends Component {
  render(){
    return (
      <div>
      <div className="bg">
        </div>
         {this.props.children}
        <h1>Footer</h1>
      </div>
    )
  }
}

export default App
